cvmblaster
===
![PYPI](https://img.shields.io/pypi/v/cvmblaster)

## Introduction
The core code of python class about finding genes in assembled genome
